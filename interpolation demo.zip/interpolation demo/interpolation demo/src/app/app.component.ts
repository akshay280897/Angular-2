import { Component } from '@angular/core';

@Component({
  selector: 'my-app',
  template: `<h1>Hello {{name}}</h1>
               <p>Arithmetic Calculation: 10+20+30 = {{10+20+30}}</p>
                <p>{{'Name = '+name}}</p>
                 <p>{{name ? name : 'No name specified'}}</p>
                  <p><img src='{{imgPath}}'></p>
                   <p>{{   'By ' + getData()}}</p>`,
})
export class AppComponent  {
    name = 'Angular';
    firstname = 'Greg';
    lastname = 'Bentley';
    imgPath = 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQ8LNvDLQFbAVaA9iZh5aKJ4q_XdFea6Ju5Kze2NY1rC7inkCno6KZlu9qC';

    getData():string
    {
        return this.firstname +' '+ this.lastname;
    }
   
}
